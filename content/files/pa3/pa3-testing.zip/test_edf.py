import json
import subprocess
from typing import Any

SCORE_PER_TEST = 8
SCORE_PER_VALGRIND_TEST = 2


def test_output(input_str: str, build_path: str) -> str:
    result = subprocess.run(
        [build_path],
        input=input_str,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"Executable failed (code {result.returncode}).\n"
            f"STDERR:\n{result.stderr}\n"
            f"STDOUT:\n{result.stdout}\n"
        )
    return result.stdout


def test_memleak(input: str, build_path: str):
    result = subprocess.run(
        ["valgrind", "--leak-check=full", "--error-exitcode=93", f"{build_path}"],
        input=input,
        capture_output=True,
        text=True,
    )

    if result.returncode == 93:
        print(f"memcheck failed:\n{result.stderr}")
        return 0

    return SCORE_PER_VALGRIND_TEST


def parse_output(stdout: str) -> dict[str, Any]:
    stdout_lines = [line.rstrip("\n") for line in stdout.splitlines()]
    output: dict[str, Any] = {}

    found_zero = False

    for line in stdout_lines:
        line = line.strip()
        if not line:
            continue

        if not found_zero:
            idx = line.find("0:")
            if idx != -1 and (idx == 0 or not line[idx - 1].isdigit()):
                line = line[idx:]
                found_zero = True

        if ":" not in line:
            continue

        left, right = line.split(":", 1)
        left = left.strip()
        right = right.strip()

        if left.isdigit():
            output.setdefault(left, []).append(right)  # list[str]
        else:
            output[left] = right  # str

    return output


def run_test(
    expected: dict[str, Any], actual: dict[str, Any]
) -> tuple[int, dict[str, Any], dict[str, Any], list[str]]:
    """
    Input: expected -> Expected output, actual -> Actual output
    Output: score, expected, actual, error message
    """
    correct = True
    score = SCORE_PER_TEST
    error_msg: list[str] = []

    for expect_key, expect_value in expected.items():
        if expect_key not in actual:
            error_msg.append(f"Missing key: {expect_key}")
            correct = False
            break

        output_value = actual[expect_key]

        if expect_key.isdigit():
            for line in expect_value:
                if line not in output_value:
                    correct = False
                    error_msg.append(f"Missing line: {line} at time step: {expect_key}")
                    break
        else:
            if str(expect_value).strip() != str(output_value).strip():
                correct = False
                error_msg.append(
                    f"Incorrect summary line: {expect_key} {expect_value} "
                )
                break
    if not correct:
        score = 0
    return (score, expected, actual, error_msg)


def format_error_str(
    test_idx: int,
    actual: dict[str, Any],
    expected: dict[str, Any],
    error_msgs: list[str],
) -> str:
    joined_errors = "\n".join(error_msgs)

    out_str = (
        f"Test {test_idx} failed!\n"
        f"Errors:\n{joined_errors}\n"
        f"Expected Output:\n{expected}\n"
        f"Actual Output:\n{actual}\n"
    )
    return out_str


def run_tests(in_out_dict: list[dict[str, Any]], build_path: str) -> tuple[int, int]:
    """
    Output: score, tests ran
    """
    tests_ran = 0
    total_score = 0
    for test in in_out_dict:
        tests_ran += 1
        parsed_out = parse_output(test_output(test["input"], build_path))
        (score, expected, actual, error_msg) = run_test(test["output"], parsed_out)
        total_score += score
        if score == 0:
            print(format_error_str(tests_ran, actual, expected, error_msg))
        else:
            print(f"Test {tests_ran} passed!")
    return (tests_ran, total_score)


def run_valgrind(in_out_dict: list[dict[str, Any]], build_path: str) -> tuple[int, int]:
    """
    Output: score, tests ran
    """
    tests_ran = 0
    total_score = 0
    for test in in_out_dict:
        tests_ran += 1
        score = test_memleak(test["input"], build_path)
        total_score += score
        if score != 0:
            print(f"Valgrind test {tests_ran} passed!")
    return (tests_ran, total_score)


if __name__ == "__main__":
    with open("tests.json", "r") as f:
        data = json.load(f)
    (tests_ran, total_score) = run_tests(data, "./edf")
    (val_tests_ran, val_total_score) = run_valgrind(data, "./edf")
    print(
        f"\nOutput:\nTests finished!\nTests ran: {tests_ran}\nTests passed: {int(total_score / SCORE_PER_TEST)}/{tests_ran}\nFinal score: {total_score}/{SCORE_PER_TEST * tests_ran}"
    )
    print(
        f"\nValgrind:\nTests ran: {val_tests_ran}\nTests passed: {int(val_total_score / SCORE_PER_VALGRIND_TEST)}\nFinal score: {val_total_score}/{SCORE_PER_VALGRIND_TEST * val_tests_ran}"
    )
